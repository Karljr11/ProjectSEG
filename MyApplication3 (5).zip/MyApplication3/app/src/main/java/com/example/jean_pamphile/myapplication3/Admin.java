package com.example.jean_pamphile.myapplication3;

public class Admin extends Account {

    private String service = "";
    private double hourlysalary;

    public Admin(String username, String password) {
        super(username, password);
    }

    public void makeServices(){
        new Services(service, hourlysalary);
        Services service;
    }
}
