package com.example.jean_pamphile.myapplication3;

public class HomeOwner extends Account {


    public HomeOwner(String username, String password) {
        super(username, password);
    }
}
