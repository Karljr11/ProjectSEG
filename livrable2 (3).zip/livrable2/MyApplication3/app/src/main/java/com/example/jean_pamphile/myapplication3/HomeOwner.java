package com.example.jean_pamphile.myapplication3;

public class HomeOwner extends Account {
private String type = "Home Owner";

    public HomeOwner(String username, String password, String type) {
        super(username, password);
    }
}
