package com.example.jean_pamphile.myapplication3;

public class Provider extends Account {

    public Provider(String username, String password) {
        super(username, password);
    }
}
